from model_loader import ModelLoader
from chat_memory import ChatMemory

print("Ollama Llama 2 CLI Chatbot (type /exit to quit)")

memory = ChatMemory(window_size=5)
model = ModelLoader(model_name="llama2", use_hf=False)

while True:
    user_input = input("You: ").strip()
    if user_input.lower() == "/exit":
        print("Exiting chatbot. Goodbye!")
        break
    # Only send the latest user input to the model
    response = model.generate(user_input)
    print(f"Bot: {response}")
    memory.add_exchange(user_input, response) 