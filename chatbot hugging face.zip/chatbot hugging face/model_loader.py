import subprocess

class ModelLoader:
    def __init__(self, model_name="llama2", **kwargs):
        self.model_name = model_name

    def generate(self, prompt):
        # Calls ollama CLI and returns the response
        result = subprocess.run(
            ["ollama", "run", self.model_name, prompt],
            capture_output=True, text=True, encoding="utf-8"
        )
        return result.stdout.strip() 