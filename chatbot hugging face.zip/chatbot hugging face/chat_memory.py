class ChatMemory:
    def __init__(self, window_size=5):
        self.window_size = window_size
        self.history = []  # List of (user, bot) tuples

    def add_exchange(self, user, bot):
        self.history.append((user, bot))
        if len(self.history) > self.window_size:
            self.history.pop(0)

    def get_context(self):
        # Returns formatted string for model context
        context = ""
        for user, bot in self.history:
            context += f"User: {user}\nBot: {bot}\n"
        return context.strip() 