import streamlit as st
from chat_memory import ChatMemory
from model_loader import ModelLoader

st.set_page_config(page_title="Ollama Llama 2 Chatbot")
st.title("Ollama Llama 2 Chatbot")

if 'memory' not in st.session_state:
    st.session_state.memory = ChatMemory(window_size=5)
if 'model' not in st.session_state:
    st.session_state.model = ModelLoader(model_name="llama2")
if 'chat_log' not in st.session_state:
    st.session_state.chat_log = []

# Custom CSS for colored chat bubbles
st.markdown(
    """
    <style>
    .user-bubble {
        background-color: #2563eb;
        color: white;
        padding: 12px 18px;
        border-radius: 18px;
        margin-bottom: 8px;
        width: fit-content;
        box-shadow: 0 0 8px #2563eb55;
    }
    .bot-bubble {
        background-color: #22c55e;
        color: white;
        padding: 12px 18px;
        border-radius: 18px;
        margin-bottom: 16px;
        width: fit-content;
        box-shadow: 0 0 8px #22c55e55;
    }
    .thinking-bubble {
        background-color: #22c55e;
        color: #e0ffe0;
        padding: 12px 18px;
        border-radius: 18px;
        margin-bottom: 16px;
        width: fit-content;
        font-style: italic;
        opacity: 0.7;
        box-shadow: 0 0 8px #22c55e55;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# Sidebar input for always-visible chat entry
with st.sidebar:
    st.header("Send a message")
    with st.form(key="chat_form", clear_on_submit=True):
        user_input = st.text_input("You:", "", key="input")
        submit = st.form_submit_button("Send")
    if st.button("Clear Chat"):
        st.session_state.memory = ChatMemory(window_size=5)
        st.session_state.chat_log = []
        st.rerun()

# Handle new user message
if submit and user_input.strip():
    # Show user message immediately
    st.session_state.chat_log.append((user_input, None))  # None for bot reply placeholder
    st.rerun()

# If the last message is waiting for a bot reply, generate it
if st.session_state.chat_log and st.session_state.chat_log[-1][1] is None:
    user_message = st.session_state.chat_log[-1][0]
    # Show chat history up to the last user message
    for user, bot in st.session_state.chat_log[:-1]:
        st.markdown(f'<div class="user-bubble">You: {user}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="bot-bubble">Bot: {bot}</div>', unsafe_allow_html=True)
    # Show the last user message and a thinking bubble
    st.markdown(f'<div class="user-bubble">You: {user_message}</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="thinking-bubble">Bot is thinking...</div>', unsafe_allow_html=True)
    # Generate bot response
    bot_response = st.session_state.model.generate(user_message)
    st.session_state.memory.add_exchange(user_message, bot_response)
    st.session_state.chat_log[-1] = (user_message, bot_response)
    st.rerun()
else:
    # Display full chat history
    for user, bot in st.session_state.chat_log:
        st.markdown(f'<div class="user-bubble">You: {user}</div>', unsafe_allow_html=True)
        st.markdown(f'<div class="bot-bubble">Bot: {bot}</div>', unsafe_allow_html=True)

st.caption("Type '/exit' to close the app or use the Clear Chat button to reset.") 